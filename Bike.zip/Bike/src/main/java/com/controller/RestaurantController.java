package com.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.dao.*;
import com.entity.*;

@Controller
public class RestaurantController {
	
	int a=RestaurantDao.take();
	//
	@RequestMapping("/s")
	public String s() 
	{
		return "RestaurantAdmin/index";
	}
	//
	@RequestMapping("/srlogin")
	public String login() {
		return "RestaurantAdmin/srlogin";	
	}


	//for home
	@RequestMapping("/srsee")
	public String sai(HttpServletRequest req,HttpServletResponse res) {
		String id=req.getParameter("Id");
		String pass=req.getParameter("Pass");
		System.out.println(id+" "+pass);
		
		return RestaurantDao.checkIdPassword(id,pass);
		
	}

	//home 
	@RequestMapping("/srhome")
	public String saia() {
		return "RestaurantAdmin/home";		
	}

	//it will return the registration page
	@RequestMapping("/showreg")
	public String registration(Model mv) {
		mv.addAttribute("RestaurantAdmin", new RestaurantAdmin());	
		return "RestaurantAdmin/showregform";	
	}

	//it will save the data into collection after open the login page
	@RequestMapping(value="/showsave")    
	public String RestaurantAdminsave(@ModelAttribute("RestaurantAdmin") RestaurantAdmin show){
		RestaurantDao.save(show);   
		return "redirect:/s";//will redirect to viewsemp request mapping    
	}

	//it give show by id
	@RequestMapping("/srprofile")
	public String profile(Model mv) {
		RestaurantAdmin show= RestaurantDao.getShowBy();
		System.out.println("after "+show.toString());
		mv.addAttribute("sho",show);
		return "RestaurantAdmin/profile";	
	}

	
	//it retrive the editform in showt
	@RequestMapping("/showedit/{id}")
	public String showtedit(@PathVariable int id,Model mv) {
		System.out.println(id);
		RestaurantAdmin show=RestaurantDao.getShowBy();  
		mv.addAttribute("RestaurantAdmin", show);
		return "RestaurantAdmin/showedit";	
	}

	
	// It updates model object at showt
	@RequestMapping(value="/showedit/updaterestaurant")    
	public String editsaveing(@ModelAttribute("RestaurantAdmin") RestaurantAdmin show){  
		System.out.println("updating");
		RestaurantDao.update(show);    
		System.out.println(show);
		return "redirect:/srhome";    
	} 
	
	//it is use for ShowRoomAdmin
	@RequestMapping("/showview")    
	public String showview(Model m){    
		List<ProductData> list=ProductDao.getsrProduct(RestaurantDao.b);    
		m.addAttribute("list",list);  
		return "RestaurantAdmin/viewbikessr";    
	}

	//booking details of customer
	@RequestMapping("/bookings") 
	public String bookings(Model m) 
	{
		List<BookingData> list=BookingDao.getbooks(RestaurantDao.b);
		m.addAttribute("list",list);
		return "RestaurantAdmin/viewbookings";
	}
	// booking conforming edit
	@RequestMapping("/editbook/{id}")
	public String bookedit(@PathVariable int id,Model mv) {
		System.out.println(id);
		BookingData book=BookingDao.getbookById(id);  
		mv.addAttribute("book", book);
		return "RestaurantAdmin/bookedit";	
	}
	// booking conforming update
	 @RequestMapping(value="/editbook/updatebook")    
	    public String updatesave(@ModelAttribute("book") BookingData bd){  
	    	System.out.println("updating status");
	    	BookingDao.update(bd);    
	        System.out.println(bd);
	        return "redirect:/bookings";    
	    }  
	
	//log out page
	@RequestMapping(value="/srlogout")    
	public String logout(){   
		RestaurantDao.out();
		return "redirect:/s";    
	} 

	//it will return the registration page
		@RequestMapping("/regsr")
		public String showProductForm(Model mv) {
			mv.addAttribute("product", new ProductData());	
			return "RestaurantAdmin/addbikesr";	
		}

		//it will save the data into collection after oopen the data
		@RequestMapping(value="/savesr")    
		public String save(@ModelAttribute("bike") ProductData cus){
			cus.setSraId(a);
			System.out.println(cus.toString());
			ProductDao.savesr(cus);   
			return "redirect:/showview";//will redirect to viewemp request mapping    
		}

		
		
		//it retrive the editform
		@RequestMapping("/editsr/{id}")
		public String edit(@PathVariable int id,Model mv) {
			System.out.println(id);
			ProductData cus=ProductDao.getproductById(id);  
			mv.addAttribute("bike", cus);
			return "RestaurantAdmin/bikeeditsr";	
		}
		
	    
	    @RequestMapping(value="/editsr/updatebikesr")    
	    public String editsave(@ModelAttribute("bike") ProductData cus){  
	    	System.out.println("updating");
	    	ProductDao.update(cus);    
	        System.out.println(cus);
	        return "redirect:/showview";    
	    }    

	    
	    //it will remove the data
	    @RequestMapping(value="/deletebikesr/{id}")    
	    public String delete(@PathVariable int id){   
	    	ProductDao.delete(id);    
	        return "redirect:/showview";    
	    } 
	  
}
