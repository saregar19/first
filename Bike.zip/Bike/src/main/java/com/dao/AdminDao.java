package com.dao;

import org.hibernate.Session;

import com.entity.Customer;
import com.entity.RestaurantAdmin;
import com.util.HibernateUtil;

public class AdminDao {
	private AdminDao(){}
	//it delete the data
		public static void delete(int id) {
			System.out.println("delete customer");
			Customer c=getCustById(id);
			Session session=HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.delete(c);
			session.getTransaction().commit();
			session.close();
			System.out.println("deleted successfully");		
		}
		public static Customer getCustById(int id) {
			
			System.out.println("Fetching Customer");
			Session session=HibernateUtil.getSessionFactory().openSession();
			Customer cust=session.load(Customer.class, id);
			session.close();
			return cust;
		}
		public static RestaurantAdmin getShowById(int id) {
			
			System.out.println("Fetching ShowRoomAdmin");
			Session session=HibernateUtil.getSessionFactory().openSession();
			RestaurantAdmin show=session.load(RestaurantAdmin.class, id);
			session.close();
			return show;
		}
		//it delete the data
				public static void sdelete(int id) {
					System.out.println("delete ShowRoomAdmin");
					
					RestaurantAdmin c=getShowById(id);
					Session session=HibernateUtil.getSessionFactory().openSession();
					session.beginTransaction();
					session.delete(c);
					session.getTransaction().commit();
					session.close();
					System.out.println("deleted successfully");		
				}

}
