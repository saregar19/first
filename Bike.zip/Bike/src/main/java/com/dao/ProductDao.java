package com.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.entity.ProductData;
import com.util.HibernateUtil;

public class ProductDao 
{
	static int a;
	static SessionFactory sessionFactory=null;

	private ProductDao() {}
	//it will save the data in database
	public static void save(ProductData bi) {
		System.out.println("creating BikesData");
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(bi);
		session.getTransaction().commit();
		session.close();
		System.out.println("BikesData created subbessfully "+bi.toString());

	}
	////////////savesr
	public static void savesr(ProductData bi) {
		System.out.println("creating ProductData");
		bi.setSraId(RestaurantDao.b);
		System.out.println(bi.toString());
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(bi);
		session.getTransaction().commit();
		session.close();
		System.out.println("Product created successfully "+bi.toString());

	}
	//////////////

	//it display the displayAll details
	public static  void displayProduct(){
		List<ProductData> productList=getProduct();
		for(ProductData product:productList)
		{
			System.out.println(product.toString());
		}
	}

	//
	public static List<ProductData> getProduct() {
		System.out.println("Fetching product");
		Session session=HibernateUtil.getSessionFactory().openSession();
		List<ProductData>	product=session.createQuery("from ProductData").list();
		session.close();
		System.out.println("Fetched "+product.size());
		return product;
	}
	//
	public static ProductData getproductById(int id) {
		a=id;
		System.out.println("Fetching ProductData");
		Session session=HibernateUtil.getSessionFactory().openSession();
		ProductData product=session.load(ProductData.class, id);
		System.out.println(product.toString());
		session.close();
		return product;
	}
	//////////////////////////////
	public static ProductData getproductBy(int a) {
		System.out.println("Fetching Customer");
		List<ProductData> bl=getProduct();
		ProductData bid=new ProductData();
		for(ProductData bd:bl)
		{
			if(a==bd.getId()) 
			{
				System.out.println("product id "+a);
				bid=bd;
				break;
			}
		}
		return bid;
	}
	public static int getproductCostById(int a) {
		System.out.println("Fetching Customer");
		List<ProductData> bl=getProduct();
		int c = 0;
		for(ProductData bd:bl)
		{
			if(a==bd.getId()) 
			{
				System.out.println("product id "+a);
				c=bd.getProductCost();
				break;
			}
		}
		return c;
	}
///////////
	
	public static List<ProductData> getsrProduct(int w) {
		System.out.println("Fetching sr product");
		List<ProductData>	product=getProduct();
		List<ProductData> srbd =new ArrayList<ProductData>();
		int q = 0;
		for(ProductData bd:product)
		{
			System.out.println(w);
			System.out.println(bd.getSraId());
			if(w==bd.getSraId()) 
			{
				srbd.add(bd);
				q++;
			}
		}
		System.out.println("Fetched sr "+q);
		return srbd;
	}
//////////
	
	//it will update particular id
	public static void update(ProductData bi) {
		System.out.println("Updating ProductData");
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		ProductData bb=session.load(ProductData.class, bi.getId());
    	bb.setProductName(bi.getProductName());
    	bb.setProductCost(bi.getProductCost());
		
		bb.setproductDescription(bi.getProductDescription());
		
		System.out.println(bi.toString());
		session.getTransaction().commit();
		session.close();
		System.out.println("Updated");

	}

	//it delete the data
	public static void delete(int id) {
		System.out.println("delete product");
		ProductData c=getproductById(id);
		Session session=HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.delete(c);
		session.getTransaction().commit();
		session.close();	
		
	}

	
}
