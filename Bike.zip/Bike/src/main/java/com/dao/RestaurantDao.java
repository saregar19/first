package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.entity.RestaurantAdmin;
import com.util.HibernateUtil;

public class RestaurantDao {
	private RestaurantDao() {}
	/////////////////
		public static int a;
		public static int b;
		
		static SessionFactory sessionFactory=null;

		//it will save the data in database
		public static void save(RestaurantAdmin show) {
			System.out.println("creating RestaurantAdmin");
			Session session=HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.save(show);
			session.getTransaction().commit();
			session.close();
			System.out.println("RestaurantAdmin created successfully "+show.toString());
		}


		//
		public static List<RestaurantAdmin> getRestaurantAdmin() {
			System.out.println("Fetching RestaurantAdmin");
			Session session=HibernateUtil.getSessionFactory().openSession();
			List<RestaurantAdmin>	show=session.createQuery("from RestaurantAdmin").list();
			session.close();
			System.out.println("Fetched "+show.size());
			return show;
		}
		

		public static RestaurantAdmin getShowById(int id) {
			
			System.out.println("Fetching RestaurantAdmin");
			Session session=HibernateUtil.getSessionFactory().openSession();
			RestaurantAdmin show=session.load(RestaurantAdmin.class, id);
			System.out.println(show.toString());
			session.close();
			return show;
			}
		public static RestaurantAdmin getShowBy() {
			System.out.println("Fetching Customer");
			List<RestaurantAdmin> custList=getRestaurantAdmin();
			RestaurantAdmin c=new RestaurantAdmin();
			for(RestaurantAdmin cust:custList)
			{
				if(a==cust.getRestaurantId()) 
				{
					System.out.println("show profile id "+a);
					c=cust;
					break;
				}
			}
			return c;
		}
		
		
		/////////////////////////////////
		public static String checkIdPassword(String email,String pass) {
			List<RestaurantAdmin> showList=getRestaurantAdmin();
			boolean che = false;
			for(RestaurantAdmin show:showList)
			{
				String idd=show.getEmail();
				String passs=show.getPassword();
				if(email.equals(idd) && pass.equals(passs)) 
				{
					a=show.getRestaurantId(); 
					b=a;
					System.out.println("checked id "+a);
					che=true;
				}
			}
				if(che==true) {
					return"redirect:/srhome";
				}
				else
				{
					return "RestaurantAdmin/srlogin";
				}
		}
		/////////////////////////////////////

		//it will update particular id
		public static void update(RestaurantAdmin show) {
			System.out.println("Updating RestaurantAdmin");
			Session session=HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			RestaurantAdmin cc=session.load(RestaurantAdmin.class, a);
	    	cc.setUserName(show.getUserName());
	    	cc.setRestaurantName(show.getRestaurantName());
			
			cc.setEmail(show.getEmail());
			cc.setAddress(show.getAddress());
			System.out.println(show.toString());
			session.getTransaction().commit();
			session.close();
			System.out.println("Updated");

		}

		//it delete the data
		public static void delete(int id) {
			System.out.println("delete RestaurantAdmin");
			
			RestaurantAdmin c=getShowById(id);
			Session session=HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.delete(c);
			session.getTransaction().commit();
			session.close();
			System.out.println("deleted successfully");		
		}

		public static int take() {
			System.out.println("dao"+b);
			return b;
		}
		public static void out() 
		{
			System.out.print(a);
			a=0;
			System.out.print(" is logged out");
		}
	////////////////

}
