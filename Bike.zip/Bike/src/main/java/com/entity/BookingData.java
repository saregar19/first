package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bookingdata")
public class BookingData {

	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	@Id
	private Integer id;
	
	@Column(name="productId")
	private Integer productId;
	
	@Column(name="customerId")
	private int customerId;
	
	@Column(name="showadminId")
	private int showadminId;
	
	@Column(name="paymentId")
	private int paymentId;
	
	@Column(name="status")
	private String status;

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getShowadminId() {
		return showadminId;
	}

	public void setShowadminId(int showadminId) {
		this.showadminId = showadminId;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	@Override
	public String toString() {
		return "BookingData [id=" + id + ", productId=" + productId + ", customerId=" + customerId + ", showadminId="
				+ showadminId + ", paymentId=" + paymentId + ", status=" + status + "]";
	}

	public BookingData() {
		super();
	}

	public BookingData( int productId, int customerId, int showadminId, int paymentId, String status) {
		super();
		
		this.productId = productId;
		this.customerId = customerId;
		this.showadminId = showadminId;
		this.paymentId = paymentId;
		this.status = status;
	}

	
	
	
}
