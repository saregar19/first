package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class ProductData
{
	
	
	///////////////////////////
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	@Id
	private int id;
	@Column(name="productName")
	private String productName;
	@Column(name="productCost")
	private int productCost;
	
	@Column(name = "productDescription")
	private String productDescription;
	@Column(name = "sraId")
	private Integer sraId;
	
	



	public int getSraId() {
		return sraId;
	}


	public void setSraId(int sraId) {
		this.sraId = sraId;
	}


	
	public int getId() {
		return id;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getProductCost() {
		return productCost;
	}


	public void setProductCost(int productCost) {
		this.productCost = productCost;
	}


	public String getProductDescription() {
		return productDescription;
	}


	public void setproductDescription(String productDescription) {
		this.productDescription = productDescription;
	}


	public void setId(int id) {
		this.id = id;
	}


	public ProductData() {}


	public ProductData(int id, String productName, int productCost, String productDescription) {
		super();
		this.id = id;
		this.productName = productName;
		this.productCost = productCost;
		this.productDescription = productDescription;
	}


	@Override
	public String toString() {
		return "ProductData [id=" + id + ", productName=" + productName + ", productCost=" + productCost
				+ ", productDescription=" + productDescription + ", sraId=" + sraId + "]";
	}
	
	
	
	



	
	
	
	
}
