package com.util;

import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;

import com.entity.*;

public class HibernateUtil {
	
	static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory(){
		if(sessionFactory==null)
		{
			Configuration c=new Configuration().addAnnotatedClass(Customer.class).addAnnotatedClass(ProductData.class).addAnnotatedClass(RestaurantAdmin.class).addAnnotatedClass(BookingData.class).configure("hibernate.cfg.xml");
			
			 sessionFactory=c.buildSessionFactory();
			
		}
		
		return sessionFactory;
	}

}
