create table bookingdata(ID int not null auto_increment,productId int,customerId int ,showadminId int, paymentId int);


	