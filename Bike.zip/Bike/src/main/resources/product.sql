create table product(ID int not null auto_increment,productName varchar(64),productCost int ,productDescription varchar(100);
